package org.inceptez.hack
//Method should remove all special characters and numbers 0 to 9 - ? , / _ ( ) [ ]

class allmethods extends java.io.Serializable
{ 
  println;println("Processing removal of Special Characters")
  def method(remspecialchar:String):String=
  {
    return remspecialchar.replaceAll("\\W", " ").replace("_", " ")
  }
}