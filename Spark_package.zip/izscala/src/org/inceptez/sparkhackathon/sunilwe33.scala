/*************************************************************************************************/
/* Author					: Sunil Ganeshan																															 */
/* Batch 					: WE-33																																				 */
/* Date  					: 30-05-2020																																	 */
/* Description		: Spark (Core, SQL, Streaming) Hackathon                                       */
/* Details				:	1. Data cleaning, cleansing, scrubbing 																			 */ 						
/* 									2. Data merging, Deduplication, Performance Tuning & Persistance						 */
/* 									3. DataFrames operations																										 */	
/* 									4. Tale of handling RDDs, DFs and TempViews (20% Completion) 								 */
/* 									5. Visualization (5% Completion)																						 */
/* 									6. Real time Streaming								 																			 */
/* Package  			: org.inceptez.sparkhackathon 																								 */
/* Calling Class	: org.inceptez.hack.allmethods																								 */
/* Version  			: 1.0																																					 */
/*************************************************************************************************/

package org.inceptez.sparkhackathon

import org.apache.spark._
import org.apache.spark.sql._
import org.apache.spark.streaming._

object sunilwe33 
{
  case class insuranceinfo(IssuerId:Int,IssuerId2:Int,BusinessDate: String,StateCode:String,SourceName:String,NetworkName:String,NetworkURL:String,CustNum:Int,MarketCoverage:String,DentalOnlyPlan:String)
  def main(args:Array[String])
  {
      //Creation of Spark Session, Spark Context, SQL Context, Hive support, Enabling Spark Logging & History Server
      val ss = SparkSession.builder().appName("Sunil's Spark Hackathon").master("local[*]")
                           .config("spark.history.fs.logDirectory", "file:///tmp/spark-events")
                           .config("spark.eventLog.dir", "file:///tmp/spark-events")
                           .config("spark.eventLog.enabled", "true")
                           .config("hive.metastore.uris","thrift://localhost:9083")
                           .config("spark.sql.warehouse.dir","hdfs://localhost:54310/user/hive/warehouse")
                           .enableHiveSupport()
                           .getOrCreate()
      
      val sc   = ss.sparkContext
      val sqlc = ss.sqlContext
      val ssc  = new StreamingContext(sc, Seconds(10))
      sc.setLogLevel("Error")
            
      println;println("Starting the execution of Hackathon")
              println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
      
      //1. Data cleaning, cleansing, scrubbing: Loading RDDs, remove header, blank lines and impose caseclass schema        
      println;println("Procession File1")
              println("----------------")
      
      val file = sc.textFile("hdfs://localhost:54310/user/hduser/spark/sparkhack/insuranceinfo1.csv")
      val fcnt = file.count()
      println;println("Total no. of records in the file (with header): " + fcnt)
      
      val fhead = file.first()
      val data  = file.filter(x=>x!=fhead)
      println("Total no. of records in the file (without header): " + data.count())
      println;println("Sample records in the file:")
      data.take(3).foreach(println)
      
      val trimdata   = data.filter(x=>x.length()!=0)
      val seldata    = trimdata.map(x=>x.split(",",-1))
                              .filter(l => l.length==10).filter(x=>x(0).nonEmpty)
      val rejectdata = trimdata.map(x=>x.split(",",-1))
                              .filter(l => l.length!=10 || l(0).isEmpty())                        
      val finaldata  = seldata.map(x=>insuranceinfo(x(0).toInt,x(1).toInt,x(2),x(3),x(4),x(5),x(6),x(7).toInt,x(8),x(9)))
                         
      println;println("Final Selected Records: " + finaldata.count())
      println("Final Rejected Records: " + rejectdata.count())
      println;println("Final Sample Records:")
      finaldata.take(3).foreach(println)
      
      println;println("Procession File2")        
              println("----------------")
      val file2 = sc.textFile("hdfs://localhost:54310/user/hduser/spark/sparkhack/insuranceinfo2.csv")
      val fcnt2 = file2.count()
      println;println("Total no. of records in the file (with header): " + fcnt2)
      
      val f2head = file2.first()
      val data2 = file2.filter(x=>x!=f2head)
      println("Total no. of records in the file (without header): " + data2.count())
      println;println("Sample records in the file:")
      data2.take(3).foreach(println)
      
      val trimdata2   = data2.filter(x=>x.length()!=0)
      val seldata2    = trimdata2.map(x=>x.split(",",-1))
                              .filter(l => l.length==10).filter(x=>x(0).nonEmpty)
      val rejectdata2 = trimdata2.map(x=>x.split(",",-1))
                              .filter(l => l.length!=10 || l(0).isEmpty())
      val finaldata2  = seldata2.map(x=>insuranceinfo(x(0).toInt,x(1).toInt,x(2),x(3),x(4),x(5),x(6),x(7).toInt,x(8),x(9)))
                         
      println;println("Final Selected Records: " + finaldata2.count())
      println("Final Rejected Records: " + rejectdata2.count())
      println;println("Final Sample Records:")
      finaldata2.take(3).foreach(println)
      
      //2. Data merging, Deduplication, Performance Tuning & Persistance
      
      val insuredatamerged = finaldata.union(finaldata2)
      
      insuredatamerged.cache()
      
      println;println("Final merged data count:" + insuredatamerged.count())
      
      if (finaldata.count() + finaldata2.count() == insuredatamerged.count())
        println("***Count Matching***")
      else 
        println("***Count Not Matching***")
        
        
      val distinctrdd = insuredatamerged.distinct()
      println;println("Count of disctinct records:" + distinctrdd.count())
      println("Count of duplicate records:" + (insuredatamerged.count() - distinctrdd.count()))

      println;println("Current Number of Patitions:" + insuredatamerged.getNumPartitions)
  
      val insuredatarepart = insuredatamerged.repartition(8)
      println;println("Repartitioned Number:" + insuredatarepart.getNumPartitions)
      
      val finalhdfs = insuredatarepart.map(x=>(x.IssuerId,x.IssuerId2,x.BusinessDate,x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.CustNum,x.MarketCoverage,x.DentalOnlyPlan))
      val rejectfile1 = rejectdata.map(x=>(x(0),x(1),x(2),x(3),x(4),x(5)))
      val rejectfile2 = rejectdata2.map(x=>(x(0),x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9)))
      
      rejectfile1.saveAsTextFile("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/rejectfile1csv")
      rejectfile2.saveAsTextFile("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/rejectfile2csv")
      finalhdfs.saveAsTextFile("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/insuredatacsv")
      insuredatamerged.unpersist()
      
      //3. DataFrames operations: Apply Structure, DSL column management functions, transformation, custom udf & schema migration.
      import org.apache.spark.storage._
      import org.apache.spark.sql.types._
      import sqlc.implicits._
      import org.apache.spark.sql.functions.{current_date,current_timestamp, date_format,concat,col,lit,udf,max,min}
      
      val insureschema = StructType(Array(StructField("IssuerId",IntegerType,true),
                                          StructField("IssuerId2",IntegerType,true),
                                          StructField("BusinessDate",DateType,true),
                                          StructField("StateCode",StringType,true),
                                          StructField("SourceName",StringType,true),
                                          StructField("NetworkName",StringType,true),
                                          StructField("NetworkURL",StringType,true),
                                          StructField("CustNum",IntegerType,true),
                                          StructField("MarketCoverage",StringType,true),
                                          StructField("DentalOnlyPlan",StringType,true)))  
      
      val insuredatarepartdf = insuredatarepart.toDF()
      
      val insuredatarepartdfrdd = insuredatarepartdf.rdd
      
      val insuredataschemadf = sqlc.createDataFrame(insuredatarepartdfrdd, insureschema)
      
      println;println("Schema of DF with case class")
      insuredatarepartdf.printSchema()
      println;println("Schema of DF with StructType")
      insuredataschemadf.printSchema()
      
      println;println("Reading multiple CSV files")                        
      val file1df   = sqlc.read.option("header", true)
                               .option("mode", "dropmalformed")
                               .option("dateFormat", "yyyy-MM-dd")
                               .schema(insureschema)
                               .csv("hdfs://localhost:54310/user/hduser/spark/sparkhack/insuranceinfo1.csv")

      val file2df   = sqlc.read.option("header", true)
                               .option("mode", "dropmalformed")
                               .option("dateFormat", "dd-MM-yyyy")
                               .schema(insureschema)
                               .csv("hdfs://localhost:54310/user/hduser/spark/sparkhack/insuranceinfo2.csv")
                                   
      val filesdf = file1df.union(file2df)
      
      println;println("Original records count:" + filesdf.count())
      println("Dropping Duplicate records")
      val insureds = filesdf.distinct()
      println("Count of New data set:" + insureds.count())
      
      //Applying DSL functions
      val insuredf = insureds.withColumnRenamed("StateCode","Stcd")
                             .withColumnRenamed("SourceName","Srcnm")
                             .withColumn("Issueridcomposite", concat('IssuerId.cast(StringType),lit(" "),col("IssuerId2").cast("String")))
                             .drop("DentalOnlyPlan")
                             .withColumn("Sysdt",current_date().as("Current Date"))
                             .withColumn("Systs",current_timestamp().as("Current Time"))
                           /*.withColumn("BusinessDate", date_format($"BusinessDate","yyyy:MM:dd"))*/
                             .na.drop()
                             .drop("StateCode","SourceName")
      
      insuredf.persist(StorageLevel.MEMORY_ONLY_SER)
      insuredf.printSchema()
      println("Total no. of records:" + insuredf.count())
      insuredf.write.mode("overwrite").csv("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/insuredfcsv")
      println;println("Sample records")
      insuredf.show(5,true)
      
      insuredf.select('IssuerId,'NetworkName).where("IssuerId=29276").show(4,false)
      val remspecialcharobj = new org.inceptez.hack.allmethods      
      val remspecialcharudf = udf(remspecialcharobj.method _)
      insuredf.select('IssuerId,remspecialcharudf('NetworkName)).where("IssuerId=29276").show(4,false)
      
      val insuredfudf = insuredf.select('IssuerId,'IssuerId2,'BusinessDate,'Stcd,'Srcnm,
                                        remspecialcharudf('NetworkName).as("NetworkName"),'NetworkURL,'CustNum,'MarketCoverage,'Issueridcomposite,
                                        'Sysdt,'Systs)
      
      println;println("Writing to JSON")
      insuredfudf.write.mode("overwrite").json("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/insuredfudfjson")
      sqlc.read.json("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/insuredfudfjson").show(5,false)
      
      println;println("Writing to CSV")
      insuredfudf.write.mode("overwrite")
                       .option("header",true)
                       .option("delimiter", "~")
                       .csv("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/insuredfudfcsv")
      
      sqlc.read.option("header",true)
               .option("delimiter", "~")
               .csv("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/insuredfudfcsv")
               .show(5,false)
      
      sqlc.sql("""create external table if not exists default.insuredata 
              (IssuerId int, IssuerId2 int, Stcd string, 
              Srcnm string,NetworkName string, NetworkURL string, CustNum int, 
              MarketCoverage string, Issueridcomposite string, Sysdt date, Systs timestamp)
              partitioned by (BusinessDate date)
              row format delimited fields terminated by ","
              location '/user/hduser/spark/sparkhack/results/'
              """)
      
      //Writing into Hive External Table
      insuredfudf.createOrReplaceTempView("sqlcudfview")
      
      println;println("Displaying view records")
      sqlc.sql("select * from sqlcudfview limit 5").show(false)
      
      println;println("Displaying Hive table records")
      
      sqlc.sql("set hive.exec.dynamic.partition.mode=nonstrict")
      
      sqlc.sql("""insert into table default.insuredata partition(BusinessDate) 
                  select IssuerId,IssuerId2,Stcd,Srcnm,NetworkName,
                  NetworkURL,CustNum,MarketCoverage,Issueridcomposite,
                  Sysdt,Systs,BusinessDate from sqlcudfview """)
      
      sqlc.sql("select * from default.insuredata limit 5").show(false)            
               
      /*4. Tale of handling RDDs, DFs and TempViews: Loading RDDs, split RDDs, Load DFs, Split DFs, Load Views, 
            Split Views, write UDF, register to use in Spark SQL, Transform, Aggregate, store in disk/DB*/   

      //Use RDD functions:
      val filerdd      = sc.textFile("hdfs://localhost:54310/user/hduser/spark/sparkhack/custs_states.csv")
      val splitrdd     = filerdd.map(x=>x.split(","))
      val custfilter   = splitrdd.filter(x=>x.length==5).map(x=>(x(0),x(1),x(2),x(3),x(4)))
      val statesfilter = splitrdd.filter(x=>x.length!=5).map(x=>(x(0),x(1)))
      
      println;println("Customer Master RDD")
      custfilter.take(3).foreach(println)
      println;println("States Code RDD")
      statesfilter.take(3).foreach(println)
      
      //Use DSL functions:
      val filedf   = sqlc.read.csv("hdfs://localhost:54310/user/hduser/spark/sparkhack/custs_states.csv")
      val custdf   = filedf.filter('_c2.isNotNull).toDF("custid","custfname","custlname","custage","custprofession")
      val statesdf = filedf.filter('_c2.isNull).drop("_c2","_c3","_c4").toDF("statecode","statedesc")
      
      println;println("Customer Master DF")
      custdf.select("*").show(3,false)
      println;println("States Code RDD")
      statesdf.select("*").show(5,false)
      
      custdf.createOrReplaceTempView("custview")
      statesdf.createOrReplaceTempView("statesview")
      insuredf.createOrReplaceTempView("insureview")
      
      sqlc.udf.register("sqlcremspecialcharudf", remspecialcharobj.method _)
      
      val finalpqdf = sqlc.sql(""" select i.IssuerId, i.IssuerId2,i.BusinessDate, 
                             year(i.BusinessDate) as yr, month(i.BusinessDate) as mth,i.Stcd,i.Srcnm, 
                             sqlcremspecialcharudf(i.NetworkName) as cleannetworkname, i.CustNum, i.MarketCoverage,
                             i.Issueridcomposite,i.Sysdt as curdt, i.Systs as curts,
                             case when i.NetworkURL like '%http%' then 'http' else 'noprotocol' end as protocol,
                             s.statedesc,c.custage,c.custprofession
                             from insureview i inner join statesview s on i.Stcd = s.statecode 
                             join custview c on i.CustNum = c.custid """)
      
      finalpqdf.select("*").show(5,false)
      
      finalpqdf.coalesce(1).write.parquet("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/finalpqdf")
      
      finalpqdf.createOrReplaceTempView("insureaggregatedview")
      val insureaggregateddf = sqlc.sql("""select row_number() over(partition by protocol order by count(custage) desc) as Seqno,
                                           cast(avg(custage) as decimal(10,2)) as Avgage,count(custage) as Count,statedesc, protocol, 
                                           custprofession from insureaggregatedview 
                                           group by statedesc, protocol, custprofession""")
      
      println;println("Final table records")
      insureaggregateddf.select("*").show(5,false)
      
      println("Writing to mysql")

      val prop=new java.util.Properties();
      prop.put("user", "root")
      prop.put("password", "root")
      
      insureaggregateddf.write.mode("overwrite")
                        .jdbc("jdbc:mysql://localhost/custdb","insureaggregated",prop)
                        
      //5. Visualization: screen prints taken from http://localhost:18080

      //6. Realtime Streaming:Chat intent identification and identification of most recurring issue use case
      
      val filest = ssc.textFileStream("hdfs://localhost:54310/user/hduser/spark/sparkhack/chatdata")
      filest.foreachRDD(x => 
        {
          val chatdf = x.map(_.split("~"))
                        .filter(x=>x.length==3)
                        .filter(x=>x(2).contains('c'))
                        .map(x=>(x(0),x(1)))
                        .map(x=>(x._1,x._2))
                        .toDF("id","chat")
            
          chatdf.createOrReplaceTempView("stdfview")
          val explodedf = sqlc.sql("select id, explode(split(chat,' ')) as chat_splits from stdfview")
          
          explodedf.createOrReplaceTempView("explodeview")
          
          val stopworddf = sqlc.read.textFile("file:///home/hduser/sparkdata/sparkhack/realtimedataset/stopwords")
                                          .toDF("stopword")
          
          stopworddf.createOrReplaceTempView("stopwordview")
          
          val finalhive = sqlc.sql("""select e.id,s.stopword from explodeview e left outer join stopwordview s
                                              on e.chat_splits = s.stopword where s.stopword is not null""")
          
          println("Writing to Hive table")
          finalhive.write.mode(SaveMode.Append).saveAsTable("default.custchat")
          
          println("Final Hive table records")
          val jsondf = sqlc.read.table("default.custchat")
          jsondf.createOrReplaceTempView("jsonview")
          println("Final Hive table records to JSON")
          sqlc.sql("""select stopword as chatkeywords, count(stopword) as occurance 
                              from jsonview group by stopword""")
                      .coalesce(1).write.mode("append").json("hdfs://localhost:54310/user/hduser/spark/sparkhack/results/custchatjson")
        })
      
      ssc.start()
      ssc.awaitTermination()
      
      println;println("End of execution of Hackathon")
              println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
      
  } /* End of Main */
} /* End of Object */